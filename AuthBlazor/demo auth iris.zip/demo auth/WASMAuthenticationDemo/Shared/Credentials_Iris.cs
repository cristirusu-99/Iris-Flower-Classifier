﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace WASMAuthenticationDemo.Shared
{
    public class Credentials_Iris
    {
        [Required]
        public float Length_petals { get; set; }
        [Required]
        public float Width_petals { get; set; }
        [Required]
        public float Length_sepals { get; set; }
        [Required]
        public float Width_sepals { get; set; }
    }
}
